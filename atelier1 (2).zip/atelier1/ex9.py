A = input("entrer A :")
matrice = [3, 5, 6], [9, 7, 3]
def find(n):
    for i in range(len(matrice)):
        for j in range(len(matrice)+1):
            if matrice[i][j] == n:
                return i,j
print(find(A))