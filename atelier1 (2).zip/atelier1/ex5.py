def longueur(ch):
    if not ch:
        return 0 #si on tape ch=""
    else:
        return 1+longueur(ch[1:])      #[1:] est utilisé pour afficher la longeur de tout le rest de le liste


ch = "20211912" #le chiffre
print("la longeure du chaine est : ",longueur(ch))

