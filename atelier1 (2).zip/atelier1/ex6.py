def tri_bull(tab):
  n = len(tab)
  for i in range(n):
       for j in range(0, n-i-1):
           if tab[j] > tab[j+1]:
               tab[j], tab[j+1] = tab[j+1], tab[j]
tab = [4, 5, 3, 6, 8, 0, 1, 2]
tri_bull(tab)
print("le tableau trié en bulle est :")
for i in range(len(tab)):
   print("%d" % tab[i], "  ", end='')




#def selection(tab):
#   for i in range(len(tab)):
#       # trouver le min
#       min = i
#   for j in range(i + 1, len(tab)):
#       if tab[min] > tab[j]:
#           min = j
#           mintab = tab[i]
#           tab[i] = tab[min]
#           tab[min] = mintab
#           return tab
#tab = [2, 1, 19, 8, 12, 23, 11, 14]
#selection(tab)
# pour afficher la liste trié !
#print("Le tableau trié pa sélection  est:")
#for i in range(len(tab)):
#    print("%d" % tab[i], "  ", end='')




#def insertion(tab):
   # Parcour de 1 à la taille du tab
#  for i in range(1, len(tab)):
#      t = tab[i]
#      j = i-1
#      while j >= 0 and t < tab[j]:
#          tab[j + 1] = tab[j]
#          j -= 1
#          tab[j + 1] = t
#tab = [13, 65, 8, 4, 45, 1, 2]
 #appellons la fonction insertion
#insertion(tab)
#print("Le tableau trié  par insertion est:")
#for i in range(len(tab)):
#   print("% d" % tab[i], " ", end='')
