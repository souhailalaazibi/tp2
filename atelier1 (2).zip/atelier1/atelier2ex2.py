lis = [17, 12, 19, 3, 5, 7, 10, 45, 2]
print("notre liste:", lis)
n = 3
output = [lis[i:i + n] for i in range(0, len(lis), n)]
print(" liste divisée:", output)
output.reverse()
print(" liste inversé", output)


