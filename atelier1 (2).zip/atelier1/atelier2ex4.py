liste1 = [1, 2, [12, 5], [6, 7], 9, 10]
liste2 = [2, [6, 7], 15, 17]
intersection2 = [x for x in liste2 if x in liste1]#selectionné les elements des 2 liste
print(intersection2)
for x in liste2:
    if x in liste1:
        liste1.remove(x)#supprimmer les elements de l'intersection
print(liste1)
