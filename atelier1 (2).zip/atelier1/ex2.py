def conv(n):
    if n == 1:
        return 1  # si le nmb egale a 1
    else:
        conv(n//2)
        rest = n % 2  # si le nombre est different de 1 il va fire une division sur 2 et enregistrer le rest des 1 ou des 0 et
        print(rest, end='')


n = int(input("veuillez entrer un nombre"))
conv(n)