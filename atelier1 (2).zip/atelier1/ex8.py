#trouver la fréquence d’un caractère dans une chaîne:
from collections import Counter
str='hello python'
frequence=Counter(str)
for (key,value) in frequence.items():   #
    print("le nombre de frequence de ",key,"est:",value)
