n = int(input("veuillez entrer un nombre:"))
def somme(n):
    if n == 1:
        return 1
    else:
        return(n+somme(n-1))#recursivité
print(somme(n)) #afficher le resultat
somme(n)    #appelé la fonction
