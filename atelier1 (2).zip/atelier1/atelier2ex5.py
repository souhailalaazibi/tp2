L = [3, 24, 85, 19, 12, 14, 6]
dic = {24: "mohamed", 12: "asmae", 6: "khadija", 14: "lamiae"}
for  x in dic:
     if x in L:
        L = [ x for x in dic]
print(L)




