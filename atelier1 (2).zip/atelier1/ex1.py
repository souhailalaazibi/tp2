def factorial(x):
    if x == 0:
        return 1
    else:
        return(x*factorial(x-1))


somme = 0
n = int(input("entrer n :"))
for i in range(1, n+1):
    somme += factorial(i)/i
print("la somme de série est :", somme)