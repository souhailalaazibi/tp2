L=[12,4,56,7,8,92,2,3,2,4,3]
for n in L: #parcourir la liste
    print(n," ",end='') #affichage de tout les elements de la liste
from collections import Counter
Counter(L)
print("les occurances de chaque element ;",Counter(L))

