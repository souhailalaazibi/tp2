#le série de fibonnacci :
def fibonnacci(n):
    if n==0:
        return 0
    elif n==1:
        return 1
    else:
        return fibonnacci(n-1)+fibonnacci(n-2)
x=int(input("enter un nombre :"))
#afficher le série de fibonnaci:
print("le série de fibonnaci de",x,"est",fibonnacci(x))
