l1 = [2, 5, 7, 8, 16, 20]
l2 = [3, 4, 6, 10, 12, 14]
for indice, element in enumerate(l1):#parcourir tout les elements
    if indice % 2 != 0:
        L11 = element
        print(L11)
for indice, element in enumerate(l2):#parcourir tout les elements
    if indice % 2 == 0:
        L22 = element
        print(L22)
        L3 = [x for x in L11 if x in L22]
        print(L3)

        
